$(function () {

    $('.tombolTambahData').on('click', function () {
        $('#apasih').html('Add New Menu');
        $('.modal-footer button[type=submit]').html('Add');
        $('#nama').val('');
        $('#nrp').val('');
        $('#email').val('');
        $('#jurusan').val('');
        $('#id').val('');
    });


    $('.tampilModalUbah').on('click', function () {
        $('#apasih').html('Edit Menuses');
        $('.modal-footer button[type=submit]').html('Edit');
        $('.modal-body form').attr('action', 'http://localhost/wpu-login/menu/ubah');

        const id = $(this).data('id');

        $.ajax({
            url: 'http://localhost/wpu-login/menu/getEdit',
            data: {
                id: id
            },
            method: 'post',
            //dataType: 'json',
            success: function (data) {
                console.log(data);
                //$('#menu').val(data.menu);
                //$('#id').val(data.id);
            }
        });

    });

});