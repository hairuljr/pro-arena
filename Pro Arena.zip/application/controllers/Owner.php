<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Owner extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'Jadwal Pertandingan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['owner'] = $this->db->get('bookingan')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('owner/index', $data);
        $this->load->view('templates/footer');
    }
    public function lapangan()
    {
        $data['title'] = 'Lapangan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['owner'] = $this->db->get('lapangan')->result_array();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('owner/lapangan', $data);
        $this->load->view('templates/footer');
    }
    public function booking()
    {
        $data['title'] = 'Booking';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['owner'] = $this->db->get('booking')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('owner/booking', $data);
        $this->load->view('templates/footer');
    }
    public function transaksi()
    {
        $data['title'] = 'Transaksi';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['owner'] = $this->db->get('image')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('owner/transaksi', $data);
        $this->load->view('templates/footer');
    }

    public function addlapangan()
    {
        $data = [
            'nama_lapangan' => $this->input->post('nama_lapangan'),
            'jenis_lapangan' => $this->input->post('jenis_lapangan'),
            'waktu' => $this->input->post('waktu'),
            'harga' => $this->input->post('harga')
        ];
        $this->db->insert('lapangan', $data);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Lapangan sudah ditambahkan!</div>');
        redirect('owner/lapangan');
    }
    public function addbooking()
    {
        $data = [

            'nama_tim' => $this->input->post('nama_tim'),
            'nama_lapangan' => $this->input->post('nama_lapangan'),
            'jenis_lapangan' => $this->input->post('jenis_lapangan'),
            'email' => $this->input->post('email'),
            'no_hp' => $this->input->post('no_hp'),
            'waktu' => $this->input->post('waktu'),
            'lama_main' => $this->input->post('lama_main')
        ];
        $this->db->insert('booking', $data);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Booking sudah ditambahkan!</div>');
        redirect('owner/booking');
    }

    public function deletelapangan($lapangan_id)
    {
        $data['owner'] = $this->db->get_where('lapangan', ['id' => $lapangan_id])->row_array();
        $this->db->where('id', $lapangan_id);
        $this->db->delete('lapangan');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Lapangan Terhapus!</div>');
        redirect('owner/lapangan');
    }
    public function deletebooking($id)
    {
        $data['owner'] = $this->db->get_where('booking', ['id' => $id])->row_array();
        $this->db->where('id', $id);
        $this->db->delete('booking');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Bookingan sudah terkonfirmasi!</div>');
        redirect('owner/booking');
    }
    public function deletejadwal($id)
    {
        $data['owner'] = $this->db->get_where('bookingan', ['id' => $id])->row_array();
        $this->db->where('id', $id);
        $this->db->delete('bookingan');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Jadwal Pertandingan Terhapus!</div>');
        redirect('owner');
    }

    public function editlapangan()
    {
        $data = [
            "nama_lapangan" => $this->input->post('nama_lapangan', true),
            "jenis_lapangan" => $this->input->post("jenis_lapangan", true),
            "waktu" => $this->input->post('waktu', true),
            "harga" => $this->input->post('harga', true)
        ];
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('lapangan', $data);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Lapangan Berhasil Diubah!</div>');
        redirect('owner/lapangan');
    }
    public function editjadwal()
    {
        $data = [
            "nama_tim" => $this->input->post('nama_tim', true),
            "nama_lapangan" => $this->input->post('nama_lapangan', true),
            "jenis_lapangan" => $this->input->post("jenis_lapangan", true),
            "waktu" => $this->input->post('waktu', true),
            "lama_main" => $this->input->post('lama_main', true)
        ];
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('bookingan', $data);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Jadwal Pertandingan Berhasil Diubah!</div>');
        redirect('owner');
    }
    public function editbooking()
    {
        $data = [
            'nama_tim' => $this->input->post('nama_tim'),
            'nama_lapangan' => $this->input->post('nama_lapangan'),
            'jenis_lapangan' => $this->input->post('jenis_lapangan'),
            'waktu' => $this->input->post('waktu'),
            'lama_main' => $this->input->post('lama_main')
        ];
        $this->db->insert('bookingan', $data);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Konfirmasi Bookingan Berhasil!</div>');
        redirect('owner/booking');
    }
}
