<!doctype html>
<html lang="en">
  <head>
   
    <title>ProArena</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="56x56" href="images/fav-icon/icon1.png">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="file_event/css/bootstrap.min.css">
    <link rel="stylesheet" href="file_event/css/jquery-ui.css">
    <link rel="stylesheet" href="file_event/css/owl.carousel.min.css">
    <link rel="stylesheet" href="file_event/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="file_event/css/owl.theme.default.min.css">

    <link rel="stylesheet" href="file_event/css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="file_event/css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="file_event/css/aos.css">

    <link rel="stylesheet" href="file_event/css/style.css">
    
  </head>
  

  <div class="container">
    <header>
      <?php 
          include "header.html";
       ?>
    </header>
    
  </div>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300" id="home-section">


    <section class="site-section" id="about-section">
      <div class="container" style="margin-top: 150px;">
        <div class="row justify-content-center" data-aos="fade-up">

        <div class="row hover-1-wrap mb-5 mb-lg-0">
          <div class="col-12">
            <div class="row">
              <div class="mb-4 mb-lg-0 col-lg-6 order-lg-2" data-aos="fade-left">
                <a href="#" class="rotate10">
                  <img src="file_event/images/p1.jpg" alt="Image" class="img-fluid">
                </a>
              </div>
              <div class="col-lg-5 mr-auto text-lg-right align-self-center order-lg-1" data-aos="fade-right">
                <h2 class="text-black">PANGGUNG FUTSAL</h2>
                <p class="mb-4">Bawa pulang hadiah puluhan juta rupiah</p>
                <p><a href="#" class="btn btn-primary">Read More</a></p>
              </div>
            </div>
          </div>
        </div>

        <div class="row hover-1-wrap mb-5 mb-lg-0">
          <div class="col-12">
            <div class="row">
              <div class="mb-4 mb-lg-0 col-lg-6"  data-aos="fade-right">
                <a href="#" class="rotate-reverse10">
                  <img src="file_event/images/p2.jpg" alt="Image" class="img-fluid">
                </a>
              </div>
              <div class="col-lg-5 ml-auto align-self-center"  data-aos="fade-left">
                <h2 class="text-black">SPECTA 2016</h2>
                <p class="mb-4">Liga Futsak Kampus, Total hadiah 12,5 juta rupiah</p>
                <p><a href="#" class="btn btn-primary">Read More</a></p>
              </div>
            </div>
          </div>
        </div>

        <div class="row hover-1-wrap mb-5 mb-lg-0">
          <div class="col-12">
            <div class="row">
              <div class="mb-4 mb-lg-0 col-lg-6 order-lg-2" data-aos="fade-left">
                <a href="#" class="rotate10">
                  <img src="file_event/images/p3.jpg" alt="Image" class="img-fluid">
                </a>
              </div>
              <div class="col-lg-5 mr-auto text-lg-right align-self-center order-lg-1" data-aos="fade-right">
                <h2 class="text-black">RAMADHAN LEAGUE</h2>
                <p class="mb-4">Futsal Papua Barat , saksikan Tim Papan atas Futsal Jogja dan Papua</p>
                <p><a href="#" class="btn btn-primary">Read More</a></p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>  



  <script src="file_event/js/jquery-3.3.1.min.js"></script>
  <script src="file_event/js/jquery-ui.js"></script>
  <script src="file_event/js/popper.min.js"></script>
  <script src="file_event/js/bootstrap.min.js"></script>
  <script src="file_event/js/owl.carousel.min.js"></script>
  <script src="file_event/js/jquery.countdown.min.js"></script>
  <script src="file_event/js/jquery.easing.1.3.js"></script>
  <script src="file_event/js/aos.js"></script>
  <script src="file_event/js/jquery.fancybox.min.js"></script>
  <script src="file_event/js/jquery.sticky.js"></script>
  <script src="file_event/js/isotope.pkgd.min.js"></script>

  
  <script src="file_event/js/main.js"></script>



  <?php 
    include "footer.html";
   ?>

  </body>
</html>