<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="row">
        <div class="col-lg">

            <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
            <?= $this->session->flashdata('message'); ?>
            <?php if (validation_errors()) : ?>
                <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>
                </div>
            <?php endif; ?>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama Tim</th>
                        <th scope="col">Nama Lapangan</th>
                        <th scope="col">Jenis Lapangan</th>
                        <th scope="col">Waktu</th>
                        <th scope="col">Durasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($owner as $jt) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $jt['nama_tim']; ?></td>
                            <td><?= $jt['nama_lapangan']; ?></td>
                            <td><?= $jt['jenis_lapangan']; ?></td>
                            <td><?= $jt['waktu']; ?></td>
                            <td><?= $jt["lama_main"]; ?> Jam</td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->