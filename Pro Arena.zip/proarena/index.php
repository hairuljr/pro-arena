<?php 
	include "header.html";
	include "main.html";
	include "footer.html";
 ?>