<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <div class="row">
        <div class="col-lg-6">
            <form action="<?= base_url('user/rincianbooking'); ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="nama_tim" name="nama_tim" placeholder="Nama Tim">
                    </div>
                    <div class="form-group">
                        <select name="nama_lapangan" id="nama_lapangan" class="form-control">
                            <option value="">Pilih Lapangan</option>
                            <?php foreach ($owner as $m) : ?>
                                <option><?= $m['nama_lapangan']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <select name="jenis_lapangan" id="jenis_lapangan" class="form-control">
                            <option value="">Pilih Jenis Lapangan</option>
                            <?php foreach ($owner as $m) : ?>
                                <option><?= $m['jenis_lapangan']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="email" name="email" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="no_hp" name="no_hp" placeholder="Nomor Handphone">
                    </div>
                    <div class="form-group">
                        <input type="datetime-local" class="form-control" id="waktu" name="waktu">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="lama_main" name="lama_main" placeholder="Lama Main dalam Jam">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-warning">Batal</button>
                    <button type="submit" class="btn btn-primary">Book</button>

                </div>
            </form>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->