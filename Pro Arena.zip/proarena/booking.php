<!DOCTYPE html>
<html>
<head>
	<title>ProArena</title>
	<meta charset="UTF-8">
		<!-- For IE -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">

		<!-- For Resposive Device -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<title>ProArena</title>

		<!-- Favicon -->
		<link rel="icon" type="image/png" sizes="56x56" href="images/fav-icon/icon1.png">


		<!-- Main style sheet -->
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<!-- responsive style sheet -->
		<link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<body>

<?php 
	include "header.html";
 ?><br><br><br>

<!--
			=====================================================
				Team Section
			=====================================================
			-->
			<div id="team-section">
				<div class="container">
					<div class="theme-title">
						<h2>Top Venue Lapangan</h2>
						<br><br><br>
					</div> <!-- /.theme-title -->

					<div class="clear-fix team-member-wrapper">
						<div class="float-left">
							<div class="single-team-member">
								<div class="img">
									<img src="images/lap/lap 1.jpg" alt="Image">
									<div class="opacity tran4s">
										<h4><a href="">Telaga Futsal</a></h4>
										<span>__</span>
										
									</div>
								</div> <!-- /.img -->
								<div class="member-name">
									<h6>Telaga Futsal</h6>
									<p>__</p>
									<ul>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
									</ul>
								</div> <!-- /.member-name -->
							</div> <!-- /.single-team-member -->
						</div> <!-- /float-left -->

						<div class="float-left">
							<div class="single-team-member">
								<div class="img">
									<img src="images/lap/lap 2.jpg" alt="Image">
									<div class="opacity tran4s">
										<h4><a href="#">Planet Futsal</a></h4>
										<span>__</span>
										
									</div>
								</div> <!-- /.img -->

								<div class="member-name">
									<h6>Planet Futsal</h6>
									<p>__</p>
									<ul>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
									</ul>
								</div> <!-- /.member-name -->
							</div> <!-- /.single-team-member -->
						</div> <!-- /float-left -->

						<div class="float-left">
							<div class="single-team-member">
								<div class="img">
									<img src="images/lap/lap 3.png" alt="Image">
									<div class="opacity tran4s">
										<h4><a href="">Forza Futsal</a></h4>
										<span>__</span>
										
									</div>
								</div> <!-- /.img -->
								<div class="member-name">
									<h6>Forza Futsal</h6>
									<p>__</p>
									<ul>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
									</ul>
								</div> <!-- /.member-name -->
							</div> <!-- /.single-team-member -->
						</div> <!-- /float-left -->
					</div> <!-- /.team-member-wrapper -->
				</div> <!-- /.conatiner -->
			</div> <!-- /#team-section -->
			

			<!-- =============================================
				Loading Transition
			============================================== -->
			<div id="loader-wrapper">
				<div id="preloader_1">
	                <span></span>
	                <span></span>
	                <span></span>
	                <span></span>
	                <span></span>
	            </div>
			</div>

			
	        <!-- Scroll Top Button -->
			<button class="scroll-top tran3s p-color-bg">
				<i class="fa fa-long-arrow-up" aria-hidden="true"></i>
			</button>




		<!-- Js File_________________________________ -->

		<!-- j Query -->
		<script type="text/javascript" src="vendor/jquery.2.2.3.min.js"></script>

		<!-- Bootstrap JS -->
		<script type="text/javascript" src="vendor/bootstrap/bootstrap.min.js"></script>

		<!-- Vendor js _________ -->
		
		<!-- revolution -->
		<script src="vendor/revolution/jquery.themepunch.tools.min.js"></script>
		<script src="vendor/revolution/jquery.themepunch.revolution.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.slideanims.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.layeranimation.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.navigation.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.kenburn.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.actions.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.video.min.js"></script>

		<!-- Google map js -->
		<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBZ8VrXgGZ3QSC-0XubNhuB2uKKCwqVaD0&callback=goMap" type="text/javascript"></script> <!-- Gmap Helper -->
		<script src="vendor/gmaps.min.js"></script>
		<!-- owl.carousel -->
		<script type="text/javascript" src="vendor/owl-carousel/owl.carousel.min.js"></script>
		<!-- mixitUp -->
		<script type="text/javascript" src="vendor/jquery.mixitup.min.js"></script>
		<!-- Progress Bar js -->
		<script type="text/javascript" src="vendor/skills-master/jquery.skills.js"></script>
		<!-- Validation -->
		<script type="text/javascript" src="vendor/contact-form/validate.js"></script>
		<script type="text/javascript" src="vendor/contact-form/jquery.form.js"></script>


		<!-- Theme js -->
		<script type="text/javascript" src="js/theme.js"></script>
		<script type="text/javascript" src="js/map-script.js"></script>

		</div> <!-- /.main-page-wrapper -->

</body>
</html>