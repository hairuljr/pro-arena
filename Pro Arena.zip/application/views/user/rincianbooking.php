<?php
$nama_tim = $_POST['nama_tim'];
$nama_lapangan = $_POST['nama_lapangan'];
$jenis_lapangan = $_POST['jenis_lapangan'];
$email = $_POST['email'];
$no_hp = $_POST['no_hp'];
$waktu = $_POST['waktu'];
$lama_main = $_POST['lama_main'];
if ($jenis_lapangan == "Vinyil") {
    $harga = $lama_main * 105000;
} else {
    $harga = $lama_main * 150000;
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <div class="card text-white bg-info mb-3" style="max-width: 25rem;">
        <div class="card-body">
            <h5 class="card-title">Transfer Bank BRI</h5>
            <p class="card-text">Trx Rek. 4809 0100 8457 530</p>
        </div>
    </div>
    <form action="<?= base_url('user/bookinglapangan'); ?>" method="post"">
    <div class=" card border-info mb-3" style="max-width: 25rem;">
        <div class="card-body text-info">
            <h5 class="card-title">Detail Booking</h5>
            <table>
                <tr>
                    <td>Nama Tim</td>
                    <td>:</td>
                    <td><input type="text" class="form-control" id="nama_tim" name="nama_tim" value="<?= $nama_tim; ?>" readonly></td>
                </tr>
                <tr>
                    <td>Nama Lapangan</td>
                    <td>:</td>
                    <td><input type="text" class="form-control" id="nama_lapangan" name="nama_lapangan" value="<?= $nama_lapangan; ?>" readonly></td>
                </tr>
                <tr>
                    <td>Jenis Lapangan</td>
                    <td>:</td>
                    <td><input type="text" class="form-control" id="jenis_lapangan" name="jenis_lapangan" value="<?= $jenis_lapangan; ?>" readonly></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td><input type="text" class="form-control" id="email" name="email" value="<?= $email; ?>" readonly></td>
                </tr>
                <tr>
                    <td>No Handphone</td>
                    <td>:</td>
                    <td><input type="text" class="form-control" id="no_hp" name="no_hp" value="<?= $no_hp; ?>" readonly></td>
                </tr>
                <tr>
                    <td>Waktu</td>
                    <td>:</td>
                    <td><input type="text" class="form-control" id="waktu" name="waktu" value="<?= $waktu; ?>" readonly></td>
                </tr>
                <tr>
                    <td>Lama Main</td>
                    <td>:</td>
                    <td><input type="text" class="form-control" id="lama_main" name="lama_main" value="<?= $lama_main; ?>" readonly></td>
                </tr>
                <tr>
                    <td>Harga</td>
                    <td>:</td>
                    <td><input type="text" class="form-control" id="harga" name="harga" value="<?= $harga; ?>" readonly></td>
                </tr>
            </table>
        </div>
</div>
<div class="modal-footer" style="max-width: 25rem;">
    <a href="<?= base_url('user/booking'); ?>" class="btn btn-warning">Kembali</a>
    <button type="submit" class="btn btn-primary">Check Out</button>
</div>

</form>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->