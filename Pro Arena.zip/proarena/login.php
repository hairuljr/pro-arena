<!DOCTYPE html>
<html lang="en">

<head>
	<title>ProArena</title>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" sizes="56x56" href="images/fav-icon/icon1.png">
	<link rel="stylesheet" type="text/css" href="file_login/css/util.css">
	<link rel="stylesheet" type="text/css" href="file_login/css/main.css">
	<!--===============================================================================================-->
</head>

<body>

	<?php
	include "header.html";
	?>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-t-50 p-b-90">
				<form class=" user login100-form validate-form flex-sb flex-w" style="margin: auto; padding-top:120px; display: block; margin-top: 0px;" method="post" action="<?= base_url('auth'); ?>>
					<span class="login100-form-title p-b-51"><b>
							Login</b>
					</span>
					<?= $this->session->flashdata('message'); ?>

					<div class="wrap-input100 validate-input m-b-16" data-validate="Username is required">
						<input class="input100" type="text" name="username" placeholder="Username">
						<span class="focus-input100"></span>
					</div>


					<div class="wrap-input100 validate-input m-b-16" data-validate="Password is required">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100"></span>
					</div>
					<div class="container-login100-form-btn m-t-17">
						<button class="login100-form-btn" style="background-color: #d73e4d;">
							Login
						</button>
					</div>
				</form>
				<hr>
				<div class="flex-sb-m w-full p-t-3 p-b-24">
					<div>
						<a class="txt1" href="<?= base_url('auth/forgotpassword'); ?>">Forgot Password?</a>
						<br>
						<a class="txt1" href="<?= base_url('auth/registration'); ?>">Create an Account!</a>
					</div>
					<div>

					</div>
				</div>


			</div>
		</div>
	</div>


	<div id="dropDownSelect1"></div>

	<?php
	include "footer.html";
	?>
</body>

</html>