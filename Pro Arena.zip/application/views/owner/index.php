<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="row">
        <div class="col-lg">

            <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
            <?= $this->session->flashdata('message'); ?>
            <?php if (validation_errors()) : ?>
                <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>
                </div>
            <?php endif; ?>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama Tim</th>
                        <th scope="col">Nama Lapangan</th>
                        <th scope="col">Jenis Lapangan</th>
                        <th scope="col">Waktu</th>
                        <th scope="col">Lama Main</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($owner as $jt) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $jt['nama_tim']; ?></td>
                            <td><?= $jt['nama_lapangan']; ?></td>
                            <td><?= $jt['jenis_lapangan']; ?></td>
                            <td><?= $jt['waktu']; ?></td>
                            <td><?= $jt['lama_main']; ?> Jam</td>
                            <td>
                                <a href="<?= base_url('owner/editjadwal/') . $jt['id']; ?>" class="badge badge-success" data-toggle="modal" data-target="#editJadwalModal<?= $jt['id']; ?>">edit</a>
                                <a href="<?= base_url('owner/deletejadwal/') . $jt['id']; ?>" class="badge badge-danger" onclick="return confirm('Anda yakin ingin hapus jadwal?');">delete</a>
                            </td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->

<!-- Modal -->
<div class="modal fade" id="addJadwalModal" tabindex="-1" role="dialog" aria-labelledby="addJadwalModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addJadwalModalLabel">Tambah Jadwal Baru</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('jadwal/addjadwal'); ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="nama_lapangan" name="nama_lapangan" placeholder="Nama Lapangan">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="jenis_lapangan" name="jenis_lapangan" placeholder="Jenis Lapangan">
                    </div>
                    <div class="form-group">
                        <input type="datetime-local" class="form-control" id="waktu" name="waktu" placeholder="Waktu Pertandingan">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="harga" name="harga" placeholder="Harga Lapangan">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<?php foreach ($owner as $jt) : ?>
    <div class="modal fade" id="editJadwalModal<?= $jt['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editJadwalModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editJadwalModalLabel">Ubah Jadwal</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?= base_url('owner/editjadwal'); ?>" method="post">
                    <input type="hidden" name="id" value="<?= $jt['id']; ?>">
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="text" class="form-control" id="nama_tim" name="nama_tim" value="<?= $jt['nama_tim']; ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="nama_lapangan" name="nama_lapangan" value="<?= $jt['nama_lapangan']; ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="jenis_lapangan" name="jenis_lapangan" value="<?= $jt['jenis_lapangan']; ?>">
                        </div>
                        <div class="form-group">
                            <input type="datetime-local" class="form-control" id="waktu" name="waktu" value="<?= (new DateTime($jt['waktu']))->format('Y-m-d\TH:i'); ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="lama_main" name="lama_main" value="<?= $jt['lama_main']; ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Ubah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>